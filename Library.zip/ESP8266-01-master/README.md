# ESP8266-01
This is a project monitoring temperatur using module ESP8266-01
Come on join:
https://duinoelektronik.blogspot.com/2018/11/upload-data-enggunakan-esp8266-01.html

Follow IG @duinogram
